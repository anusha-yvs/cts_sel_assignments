package PKG_1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCase {
		LoginCase demoweb;
	@Test
	public void test1()
	{
		String act_res;
		String exp_res = "yvsalekhya1@gmail.com";
		demoweb = new LoginCase();
		act_res = demoweb.Login();
		Assert.assertEquals(act_res, exp_res);
	}
	
	}

