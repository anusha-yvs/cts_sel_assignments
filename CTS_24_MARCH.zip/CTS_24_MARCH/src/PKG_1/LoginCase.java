package PKG_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginCase {
	public String Login()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://webdemoshop.tricentis.com");
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("yvsalekhya1@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("anusha");
		dr.findElement(By.xpath("//input[@value='Log in'")).click();
		String act_res= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).getText();
		
		return act_res ;
	}
}
